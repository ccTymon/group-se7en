package interface_adapter.loggedin;

public class LoggedinState {
    private String username = "";

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
}
