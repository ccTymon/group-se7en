package interface_adapter.showmovie;

public class MovieController {
}
