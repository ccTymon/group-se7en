package use_case.showmovie;

public interface MovieInputBoundary {
}
