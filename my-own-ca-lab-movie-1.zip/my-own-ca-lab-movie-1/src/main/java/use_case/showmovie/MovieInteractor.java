package use_case.showmovie;

public class MovieInteractor {
}
