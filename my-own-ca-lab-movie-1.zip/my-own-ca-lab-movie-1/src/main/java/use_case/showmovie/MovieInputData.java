package use_case.showmovie;

public class MovieInputData {
}
