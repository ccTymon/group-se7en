package use_case.showmovie;

public interface MovieOutputBoundary {
}
