package use_case.showmovie;

public class MovieOutputData {
}
